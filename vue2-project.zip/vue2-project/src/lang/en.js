export default {
     //导航英文翻译
     menu: {
        home: "home",
        product: "productManage",
      },
      //首页的英文翻译
      home: {},
}