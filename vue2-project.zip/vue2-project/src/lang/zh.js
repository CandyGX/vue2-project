export default {
    //导航中文翻译
    menu: {
        home: "首页",
        product: "产品管理",
      },
      //首页的中文翻译
      home: {},
}