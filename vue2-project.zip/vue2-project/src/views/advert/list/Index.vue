<template>
  <h1>广告列表</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>